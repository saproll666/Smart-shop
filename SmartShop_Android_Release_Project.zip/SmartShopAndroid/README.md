# Smart Shop Android

Aplikasi kasir warung sembako Smart Shop, offline-first, berbasis Android WebView.

## Build APK release

### Dengan Android Studio
1. Buka folder proyek ini.
2. Tunggu Gradle sync selesai.
3. Pilih **Build > Generate App Bundles or APKs > Generate APKs**.
4. APK release tersedia di `app/build/outputs/apk/release/`.

### Dengan GitHub Actions
Workflow `.github/workflows/build-release.yml` dapat menjalankan build release secara otomatis di GitHub Actions. Jalankan workflow `Build Smart Shop APK`, lalu unduh artifact `SmartShop-release-apk`.

Catatan: APK release dari proyek ini belum ditandatangani dengan keystore produksi. Untuk distribusi resmi/Play Store, buat dan simpan keystore signing sendiri.
